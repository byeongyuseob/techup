# 모니터링 스택 배포 가이드

## 시스템 요구사항
- OS: RHEL/CentOS/Rocky Linux 7/8/9
- CPU: 최소 2 Core
- RAM: 최소 4GB (권장 8GB)
- Disk: 최소 20GB

## 설치 순서
1. `deploy.sh` 실행으로 자동 설치
   ```bash
   chmod +x deploy.sh
   sudo ./deploy.sh
   ```

또는 수동 설치:
1. Repository 설정: `./deploy-scripts/01-setup-repo.sh`
2. Docker 설치: `./deploy-scripts/02-install-docker.sh`
3. 이미지 Pull: `./deploy-scripts/03-pull-images.sh`
4. 프로젝트 배포: `./deploy-scripts/05-deploy-stack.sh`

## 환경 설정
`.env` 파일에서 필요한 설정 변경:
- NFS_SERVER_IP: NFS 서버 IP 주소
- MYSQL_ROOT_PASSWORD: MySQL 비밀번호
- GF_SECURITY_ADMIN_PASSWORD: Grafana 관리자 비밀번호

## 서비스 접속
- HAProxy: http://서버IP
- Grafana: http://서버IP:3000 (admin/naver123)
- Prometheus: http://서버IP:9090
- Alertmanager: http://서버IP:9093
- Portainer: http://서버IP:9000

## 유용한 명령어
```bash
# 서비스 시작
docker compose up -d

# 서비스 중지
docker compose down

# 로그 확인
docker compose logs -f [서비스명]

# 상태 확인
docker compose ps
```

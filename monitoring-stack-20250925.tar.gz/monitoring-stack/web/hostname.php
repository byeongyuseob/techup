<?php
echo "Server Hostname: " . gethostname() . "\n";
?>